package com.example.dndhelper;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ListView listView;

    public static final String SHARED_PREFS = "sharedPrefs";
    public static final String TEXT = "text";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.character_list);
        ArrayList<CharProfile> names = initCharList();
        ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1,names);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String myChar = (String) parent.getItemAtPosition(position);
                loadCharacter(myChar);
            }
        });

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                newCharacter();
            }
        });
    }

    private void loadCharacter(String c) {
        //Send Character Data To Fragments
    }

    private void newCharacter() {
        Intent intent = new Intent(this,NewCharacter.class);
        startActivity(intent);
    }

    private ArrayList<CharProfile> initCharList() {
        ArrayList<CharProfile> charList = new ArrayList<>();

        return charList;
    }
}
